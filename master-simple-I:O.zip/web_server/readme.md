**1** open minifier.html  
**2** paste the html code in the upper textfield  
**3** click on `minifiy + byte-ify`  
**4** copy the results  
**5** go to data.h and replace the array (of the changed html file) with the copied bytes  

**now compile and upload your new sketch :)**
